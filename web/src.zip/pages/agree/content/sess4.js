/**
 * @file 모바일/agree/index.js
 * @brief 설정
 * @todo
 */

import React, {useState, useEffect, useContext} from 'react'
import styled from 'styled-components'

export default props => {
  //---------------------------------------------------------------------

  return (
    <>
      <h1>444</h1>
    </>
  )
}
